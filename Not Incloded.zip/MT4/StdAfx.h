//+------------------------------------------------------------------+
//|                                         MetaTrader 4 Manager API |
//|                   Copyright 2001-2014, MetaQuotes Software Corp. |
//|                                        http://www.metaquotes.net |
//+------------------------------------------------------------------+
#pragma once
//---
#ifndef WINVER  
#define WINVER 0x0500
#define _WIN32_WINNT 0x0500
#endif

#include <stdio.h>
#include <time.h>
#include <conio.h>
#include <process.h>
#include <windows.h>
//{{AFX_INSERT_LOCATION}}
//+------------------------------------------------------------------+
#pragma comment(lib,"WS2_32")