#pragma once
#include "stdafx.h"
#include "MTMarginLevel.h"
namespace MT4Wrapper {

	MTMarginLevel::MTMarginLevel() : ManagedObject(new Core::MTMarginLevel()) 
	{

	}
}
