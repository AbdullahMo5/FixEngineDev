#include "stdafx.h"
#include "MT4User.h"

namespace MT4Wrapper {
	
}