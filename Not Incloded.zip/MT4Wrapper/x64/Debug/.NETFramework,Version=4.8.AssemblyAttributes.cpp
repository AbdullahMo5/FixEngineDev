#using <mscorlib.dll>
[assembly: System::Runtime::Versioning::TargetFrameworkAttribute(L".NETFramework,Version=4.8", FrameworkDisplayName=L".NET Framework 4.8")];
